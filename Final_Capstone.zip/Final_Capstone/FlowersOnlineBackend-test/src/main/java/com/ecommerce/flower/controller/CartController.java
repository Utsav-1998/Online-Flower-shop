package com.ecommerce.flower.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.flower.entity.Cart;
import com.ecommerce.flower.service.CartService;

@RestController
@CrossOrigin
public class CartController {
	
	@Autowired
	CartService ccs;
	
	@PostMapping("/addToCart")
	public  ResponseEntity<Cart> addToCart(@RequestBody Cart cart) {
		Cart c = ccs.addToCart(cart);
		return new ResponseEntity<Cart>(c,HttpStatus.CREATED);

	}

	@PostMapping("/addToCartMultiple")
	public  ResponseEntity<List<Cart>> addToCartMultiple(@RequestBody List<Cart> carts) {
		List<Cart> l1 = new ArrayList<>();
		Iterator<Cart> i = carts.iterator();
		Cart c1;
		Cart c2;
		while (i.hasNext()){
			c1=i.next();
			c2=ccs.addToCart(c1);
			l1.add(c2);
		}
		return new ResponseEntity<List<Cart>>(l1,HttpStatus.CREATED);

	}

	@PostMapping("/getCartById")
	public  ResponseEntity<List<Cart>> getCartById(@RequestBody Cart cart) {
		List<Cart> carts = ccs.getCartById(cart);
		Iterator<Cart> i = carts.iterator();
		List<Cart> l1 = new ArrayList<>();
		Cart c1;
		while (i.hasNext()){
			c1=i.next();
			l1.add(c1);
		}
		return new ResponseEntity<List<Cart>>(l1,HttpStatus.OK);

	}

	@PostMapping("/updateCart")
	public ResponseEntity<Cart> updateCart(@RequestBody Cart cart) {
		
		Cart c2 = ccs.updateCart(cart);
		
		return new ResponseEntity<Cart>(c2,HttpStatus.OK);

	}

	@PostMapping("/deleteCart")
	public ResponseEntity<String> deleteCart(@RequestBody Cart cart) {
		String s = ccs.deleteCart(cart);
		return new ResponseEntity<String>(s,HttpStatus.OK);
	}

}
