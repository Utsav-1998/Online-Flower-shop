package com.ecommerce.flower.controller;

import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.flower.entity.Customer;
import com.ecommerce.flower.service.CustomerService;
import com.ecommerce.flower.service.EmailService;

@RestController
@CrossOrigin
//@RequestMapping("/api")
public class CustomerController {

	@Autowired
	CustomerService cs;

	@Autowired
	private EmailService sender;

	@PostMapping("/sendRegisterEmail")
	public ResponseEntity<Customer> sendRegisterEmail(@RequestBody Customer customer) {
		try {
			sender.sendRegisterEmail(customer);
			return new ResponseEntity<>(customer, HttpStatus.OK);
		} catch (MessagingException e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/login")
	public ResponseEntity<Customer> login(@RequestBody Customer cust) {
		Customer c = cs.login(cust);
		return new ResponseEntity<Customer>(c, HttpStatus.OK);
	}

	@PostMapping("/forgotPass")
	public ResponseEntity<String> forgotPass(@RequestBody Customer cust) {
		String c = cs.forgotPassword(cust);
		return new ResponseEntity<String>(c, HttpStatus.OK);
	}

	@GetMapping("/getAllCustomer")
	public ResponseEntity<List<Customer>> getAllCustomer() {
		List<Customer> l = cs.getAllCustomer();
		return new ResponseEntity<List<Customer>>(l, HttpStatus.OK);

	}

	@PostMapping("/addCustomer")
	public ResponseEntity<String> addCustomer(@RequestBody Customer cust) {
		String c = cs.addCustomer(cust);
		return new ResponseEntity<String>(c, HttpStatus.CREATED);

	}

	@PostMapping("getCustomerByCity")
	public ResponseEntity<List<Customer>> getCustomerByCity(@RequestBody Customer cust) {
		List<Customer> l = cs.getCustomerByCity(cust);
		return new ResponseEntity<List<Customer>>(l, HttpStatus.OK);
	}

	@PostMapping("getCustomerByCountry")
	public ResponseEntity<List<Customer>> getCustomerByCountry(@RequestBody Customer cust) {
		List<Customer> l = cs.getCustomerByCountry(cust);
		return new ResponseEntity<List<Customer>>(l, HttpStatus.OK);
	}

	@GetMapping("/listAllCity")
	public ResponseEntity<List<String>> listAllCity() {

		List<String> cityList = cs.listAllCity();
		return new ResponseEntity<List<String>>(cityList, HttpStatus.OK);

	}

	@GetMapping("/listAllCountry")
	public ResponseEntity<List<String>> listAllCountry() {

		List<String> countryList = cs.listAllCountry();
		return new ResponseEntity<List<String>>(countryList, HttpStatus.OK);

	}

}
