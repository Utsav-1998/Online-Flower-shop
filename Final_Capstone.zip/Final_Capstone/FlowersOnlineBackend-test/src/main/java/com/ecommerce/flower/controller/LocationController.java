package com.ecommerce.flower.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.flower.entity.Location;
import com.ecommerce.flower.service.LocationService;

@RestController
@CrossOrigin
//@RequestMapping("/api")
public class LocationController {
	
	@Autowired
	private LocationService locationService;
	

	
	@PostMapping("/editLocation")
	public  ResponseEntity<Location> editLocation(@RequestBody Location location) {
	    Location res= locationService.editLocation(location);
        return new ResponseEntity<Location>(res,HttpStatus.OK);
	}

	@PostMapping("/deleteLocation")
	public ResponseEntity<String> deleteLocation(@RequestBody Location location) {
		String res=locationService.deleteLocation(location);
        return new ResponseEntity<String>(res,HttpStatus.OK);
	}

	 @GetMapping("/findAllLocations")
	 public ResponseEntity<List<Location>> findAllLocation() {
	   List<Location> locationList = locationService.findAllLocation();
	   return new ResponseEntity<List<Location>>(locationList,HttpStatus.OK);
	 }

	 
	 @PostMapping("/addLocation")
	 public ResponseEntity<Location> addLocation(@RequestBody Location location) {
	   Location add =  locationService.addLocation(location);
	   return new ResponseEntity<Location>(add,HttpStatus.CREATED);
	 }

}
