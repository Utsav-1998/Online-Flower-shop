package com.ecommerce.flower.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.flower.entity.Product;
import com.ecommerce.flower.service.ProductService;

@RestController
@CrossOrigin
public class ProductController {
	
	@Autowired
	ProductService ps;
	
	
	@PostMapping("/addProductWithImage")
	public ResponseEntity<String> addProductWithImage(@RequestBody Product product) {
		String addProduct = ps.addProductwithImage(product);
		return new ResponseEntity<String>(addProduct,HttpStatus.CREATED);
	}
	
	@PostMapping("/updateProduct")
	public ResponseEntity<String> updateProduct(@RequestBody Product product) {
		String res= ps.updateProduct(product);
        return new ResponseEntity<String>(res,HttpStatus.OK);
	}
	
	@PostMapping("/deleteProduct")
	public ResponseEntity<String> deleteProduct(@RequestBody Product product) {
		String s = ps.deleteProduct(product);
		return new ResponseEntity<String>(s,HttpStatus.OK);

	}
	
	@GetMapping("/getAllProductWithImage")
	public ResponseEntity<List<Product>> getAllProductWithImage() {
		List<Product> prodList =  ps.getAllProductWithImage();
		return new ResponseEntity<List<Product>>(prodList,HttpStatus.OK);
		
	}
	
	@PostMapping("getByCategory")
	public ResponseEntity<List<Product>> getByCategory(@RequestBody Product product) {
		List<Product> categories  = ps.getByCategory(product);
		return new ResponseEntity<List<Product>>(categories,HttpStatus.OK);
	}
	
	@PostMapping("/getProductByName")
	public ResponseEntity<List<Product>> getProductByName(@RequestBody Product product) {
		List<Product> prodName = ps.getProductByName(product);
		return new ResponseEntity<List<Product>>(prodName,HttpStatus.OK); 
	}

	@PostMapping("/sortBySize")
	public ResponseEntity<List<Product>> sortBySize(@RequestBody Product product) {
		List<Product> sortedProd =  ps.sortBySize(product);
		return new ResponseEntity<List<Product>>(sortedProd,HttpStatus.OK);

	}

	@PostMapping("/sortByPrice")
	public  ResponseEntity<List<Product>> sortByPrice(@RequestBody Product product) {
		List<Product> sortedPrice =  ps.sortByPrice(product);
		return new ResponseEntity<List<Product>>(sortedPrice,HttpStatus.OK);

	}
	
	

}
