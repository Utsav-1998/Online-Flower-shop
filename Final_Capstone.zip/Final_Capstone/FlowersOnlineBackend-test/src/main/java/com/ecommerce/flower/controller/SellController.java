package com.ecommerce.flower.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.flower.entity.Sell;
import com.ecommerce.flower.service.SellService;

@RestController
@CrossOrigin
public class SellController {
	
	@Autowired
	SellService ss;
	
	@PostMapping("/sellReports")
	public ResponseEntity<List<Sell>> sellReports(@RequestBody String body) {
		List<Sell> getReport  = ss.sellReports(body);
		return  new ResponseEntity<List<Sell>>(getReport,HttpStatus.OK);
	}

	@PostMapping("/addSell")
	public  ResponseEntity<String> addSell(@RequestBody Sell sel) {
		String sellingReport =  ss.addSell(sel);
		return new ResponseEntity<String>(sellingReport,HttpStatus.OK);
	}

}
