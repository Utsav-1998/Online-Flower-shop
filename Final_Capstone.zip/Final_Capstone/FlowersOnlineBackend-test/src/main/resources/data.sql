insert into product(pid,category,count,date,description,name,price,size) values(1,'Anniversary',5,NOW(),'Exquisite Rose-Bundle','a1',600,'Medium');
insert into product(pid,category,count,date,description,name,price,size) values(2,'Anniversary',10,NOW(),'Lovers Delight','a2',6200,'Medium');
insert into product(pid,category,count,date,description,name,price,size) values(3,'Birthday',6,NOW(),'Deluxe pink-Roses','b1',2500,'Large');
insert into product(pid,category,count,date,description,name,price,size) values(4,'Birthday',4,NOW(),'Anniversary Bouquet','b2',400,'Large');
insert into product(pid,category,count,date,description,name,price,size) values(5,'Marriage',5,NOW(),'Bouquet of Pink Roses','m1',4000,'Large');
insert into product(pid,category,count,date,description,name,price,size) values(6,'Anniversary',10,NOW(),'Lillies and Roses','a3',900,'Large');
insert into product(pid,category,count,date,description,name,price,size) values(7,'Marriage',10,NOW(),'Sunset lillies','m5',5000,'Large');
insert into location(id,name,phone,address) values(1,'Bloom Flowers Boutique','32113455678','Ballygunge, Kolkata');
insert into location(id,name,phone,address) values(2,'Ferns N petals','88899233455','Salt Lake City, Kolkata');
insert into location(id,name,phone,address) values(3,'Natural  Flowers Shop ','970293701293','New Alipur, Kolkata');
insert into location(id,name,phone,address) values(4,'FlowerAura Franchise','768902339018','South Dumdum, Kolkata');
insert into customer(uid,city,country,email,fname,lname,mobile,password,title) values(1,'Kolkata','India','utsavnth@gmail.com','utsav','nath','82991919','hello','Mr.');

