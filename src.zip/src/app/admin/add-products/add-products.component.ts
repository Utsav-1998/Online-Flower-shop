import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';


@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css']
})
export class AddProductsComponent implements OnInit {

  constructor(private as: AdminService,
    private router: Router) { }

  ngOnInit(): void {
    
  }

  pn :string = '';
  des:string = '';
  size :string = '';
  price :string = '';
  ca :string = '';
  co :string = '';
  errMsg : string = '';
  pcodePattern :string =  "^[aA-zZ0-9_-]{1,2}$";
  descPattern :string = "^[^0-9]+$";
  pricePattern:string ="^([1-9][0-9\\.]{0,2})$";
  countPattern:string="^([1-9][0-9]{0,2}|1000)$";

  public addProduct(): void {
    this.errMsg = '';
    
    var data = {
      name: this.pn,
      description: this.des,
      size: this.size,
      price: this.price,
      category: this.ca,
      count: this.co
    };
    
    this.as.addProductWithImage(data).subscribe((data1: any) => {
      console.log(data1);
      if (data1 == "Success") {
        this.errMsg = data1.msg;
        this.pn = '';
        this.des = '';
        this.size = '';
        this.price = '';
        this.ca = '';
        this.co = '';
        this.router.navigate(["admin/view"]);
      } 
      else {
        this.errMsg = data1;
      }
    }) 
  }

}
