import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }
  endpoint = 'http://localhost:8080/';


  public getProducts(): Observable<any> {
    return this.http.get(this.endpoint + 'getAllProductWithImage');
  }

  public getAllCustomer(): Observable<any> {
    return this.http.get(this.endpoint + 'getAllCustomer');
  }

  public listAllCity(): Observable<any> {
    return this.http.get(this.endpoint + 'listAllCity');
  }

 public listAllCountry(): Observable<any> {
    return this.http.get(this.endpoint + 'listAllCountry');
  }

 public addProduct(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addProduct',data,{responseType: 'json'});
  }

public   getProductsbyCategory(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'getByCategory',data,{responseType: 'json'});
  }

 public addProductWithImage(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addProductWithImage',data,{responseType: 'text'});
  }
  
  public updateProduct(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'updateProduct',data,{responseType: 'text'});
  }
  public getCustomerByCity(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'getCustomerByCity',data,{responseType: 'json'});
  }
  public getCustomerByCountry(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'getCustomerByCountry',data,{responseType: 'json'});
  }
  public sellReports(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'sellReports',data,{responseType: 'json'});
  }
  public deleteProduct(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'deleteProduct',data,{responseType: 'text'});
  }
  public addLocation(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addLocation',data,{responseType: 'json'});
  }
 public  allLocation(): Observable<any> {
    return this.http.get(this.endpoint + 'findAllLocations',{responseType: 'json'});
  }
  public deleteLocation(data:any):Observable<any> {
    return this.http.post(this.endpoint + 'deleteLocation',data,{responseType: 'text'});
  }
 public  updateLocation(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'editLocation',data,{responseType: 'text'});
  }
}
