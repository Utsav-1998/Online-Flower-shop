import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from 'src/app/customers/customer-service.service';
import { Router } from '@angular/router';
import { SharedServiceService } from 'src/app/customers/shared-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  uName:string='';
  pass :string='';
  errMsg:string = "";
  unamePattern:string = "^[aA-zZ0-9_-]{5,10}$"; 
  pwdPattern:string  = "^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{4,12}$";
  
  login():void{
    if(this.uName=="Admin" && this.pass=="Admin123"){
      this.router.navigate(["admin/"]);
    }else{
      this.errMsg="Invalid userId or password"
    }
  }

}
