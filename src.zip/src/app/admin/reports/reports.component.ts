import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})

export class ReportsComponent implements OnInit {

  constructor(private as: AdminService) {}

  sd: string = 'today';
  selectedCity: string = '';
  selectedCountry: string = '';
  sList: Array<any> = [];
  custList: Array<any> = [];
  cityList: Array<any> = [];
  countryList: Array<any> = [];
  catList: Array<any> = [];
  ca: string = 'Birthday';

  ngOnInit(): void {

    this.sd = 'today';
    this.ca = 'Birthday';
    this.filterChange();

    this.as.getAllCustomer().subscribe((res: any) => {
      this.custList = res;
    });
    this.as.listAllCity().subscribe((res: any) => {
      this.cityList = res;
    });

    this.as.listAllCountry().subscribe((res: any) => {
      this.countryList = res;
    });

    var data = { category: this.ca };

    this.as.getProductsbyCategory(data).subscribe((data1: any) => {
      this.catList = data1;
    });
  }


  public filterChange(): void {
    var data = {
      msg: this.sd
    }
    this.as.sellReports(data).subscribe((res: any) => {
      this.sList = res;
    });
  }

  public filterCity(): void {
    if (this.selectedCity == '') {
      this.as.getAllCustomer().subscribe((res: any) => {
        this.custList = res;
      });
    } else {

      var data = {
        city: this.selectedCity
      }
      this.as.getCustomerByCity(data).subscribe((res: any) => {
        this.custList = res;
      });
    }
  }

  public filterCon(): void {
    if (this.selectedCountry == '') {
      this.as.getAllCustomer().subscribe((res: any) => {
        this.custList = res;
      });
    } else {
      var data = {
        country: this.selectedCountry
      }
      this.as.getCustomerByCountry(data).subscribe((res: any) => {
        this.custList = res;
      });
    }
  }


  public filterCategory(): void {
    var data = { category: this.ca };
    this.as.getProductsbyCategory(data).subscribe((data1: any) => {
      this.catList = data1;
    });
  }

 public fireEvent() : void {
    const ws: XLSX.WorkSheet=XLSX.utils.table_to_sheet(this.custList);
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
  /* save to file */
  XLSX.writeFile(wb, 'CustomerSummary.xlsx');
  }
}  

