import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-view-location',
  templateUrl: './view-location.component.html',
  styleUrls: ['./view-location.component.css']
})
export class ViewLocationComponent implements OnInit {

  constructor(private as:AdminService) { }

  ngOnInit(): void {
    this.allLocation();
  }
  public pList: any = [];
  public tempList: any = [];
  pageNumber:number = 1;
  pageSize:number = 8;
  errMsg:string= '';
  LocNamePattern :string = "^[aA-zZ_ -][^0-9]{3,40}$";
  addrPattern :string = "^[aA-zZ_- ,][^0-9]{3,25}$";
  mobnumPattern:string = "^((\\+91-?)|0)?[0-9]{10}$";

  
  allLocation():void{
    this.as.allLocation().subscribe((data: any) => {
      console.log(data);
      this.pList = data;
    this.tempList = this.pList.slice(this.pageSize * (this.pageNumber - 1), (this.pageSize * (this.pageNumber - 1)) + this.pageSize)
    });
  }

  
  selectedItem: any = {
    "id": 0,
    "name": "",
    "phone": "",
    "address": "",
  };

  editLocation(x: any): void {
    this.selectedItem = {
      "id": x.id,
      "name": x.name,
      "phone": x.phone,
      "address": x.address,
      
    };
    
  }
  selectedId = 0;
  public deleteLocation(x: any): void {
    this.selectedId = x.id;
    
  }
  
 public  updateLocation(): void {
    this.as.updateLocation(this.selectedItem).subscribe((data: any) => {
      if (data !=null) {
        document.getElementById("closeModal")?.click();
        this.allLocation();
      }
    });
    
  }

  public deleteLocationbyId(): void {
    var data = {
      id: this.selectedId
    }
    this.as.deleteLocation(data).subscribe((data1: any) => {
      if (data1== "Success") {
        document.getElementById("closeModal1")?.click();
        this.allLocation();
      }
    });
  }


}
