import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {

  constructor(private as: AdminService, private router: Router) { }

  ngOnInit(): void {
    this.getAllProducts();
  }

  public pList: string[] = [];
  public tempList: string[] = [];
  pageNumber:number = 1;
  pageSize :number= 15;
  errMsg :string= '';
  descPattern :string = "^[^0-9]+$";
  pricePattern:string ="^([1-9][0-9]{0,2})$";
  countPattern:string="^([1-9][0-9]{0,2}|1000)$";
  size  :string[] = ["Small","Medium","Large"];
  category : string [] =["Marriage","Anniversary","Birthday"];
  selectedItem: any = {}
  selectedId :number= 0;
  
  
 public  getAllProducts(): void {
    this.as.getProducts().subscribe((data: any) => {
      console.log(data);
      this.pList = data;
      this.tempList = this.pList.slice(this.pageSize * (this.pageNumber - 1), (this.pageSize * (this.pageNumber - 1)) + this.pageSize)
    });
  }

 
public  editProduct(x: any): void {
    this.selectedItem = {
      "pid": x.pid,
      "name": x.name,
      "image": x.image,
      "description": x.description,
      "size": x.size,
      "price": x.price,
      "category": x.category,
      "date": x.date,
      "count": x.count
    };
    
  }
  
 
  public  deleteProduct(x: any): void {
    this.selectedId = x.pid;
    
  }
 
  public  updateProduct(): void {
    this.as.updateProduct(this.selectedItem).subscribe((data: any) => {
      if (data == "Success") {
        document.getElementById("closeModal")?.click();
        this.getAllProducts();
      }
    });
    
  }
 
 
  public deleteProductbyId(): void {
    var data = {
      pid: this.selectedId
    }
    this.as.deleteProduct(data).subscribe((data1: any) => {
      if (data1== "Success") {
        document.getElementById("closeModal1")?.click();
        this.getAllProducts();
      }
    });
  }

}
