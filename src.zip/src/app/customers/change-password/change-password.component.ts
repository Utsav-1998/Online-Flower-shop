import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../customer-service.service';

@Component({
    selector: 'change-password',
    templateUrl: 'change-password.component.html',
    styleUrls: ['change-password.component.css']
})
export class ChangePasswordComponent {

    constructor(private cs: CustomerServiceService,
        private router: Router) { }

    cPass: string = '';
    pass1: string = '';
    email: string = '';
    err1: string = '';
    emailPattern = "[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}";
    pwdPattern = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}";


    ngOnInit(): void { }


    public changePass() : void {
        this.err1 = '';
        if (this.pass1 == this.cPass) {
            var data = {
                email : this.email,
                password: this.pass1
            }
            this.cs.forgotPassword(data).subscribe((result: any) => {
                console.log(result);
                this.router.navigate(["customers/products"]);

            })
        } else {
            this.err1 = "Password Mismatched!";
        }

    };
}
