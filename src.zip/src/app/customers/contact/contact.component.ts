import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../customer-service.service';
import { SharedServiceService } from '../shared-service.service';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private cs:CustomerServiceService,private router:Router) { }

  ngOnInit(): void {
  }
  name: string='';
  email : string='';
  des :string ='';
  namePattern = "^[aA-zZ_-][^0-9]{2,15}$";
  emailPattern = "[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}";
  queryPattern = "^[aA-zZ_ -][^0-9]{2,30}$";

  public contact():void{
    var contact = {
      name: this.name,
      email: this.email,
      des:this.des
    };
    this.cs.contactUs(contact).subscribe(
      res => {
        console.log(res);
      }
    );
    alert(`Thank you For Contacting Flowers Online Services!`);
    this.router.navigate(['customers/products']);
  }

}
