import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  constructor(private http: HttpClient) { }
  endpoint = 'http://localhost:8080/';


  public getProducts(): Observable<any> {
    return this.http.get(this.endpoint + 'getAllProduct');
  }
  
 public  getAllProductWithImage(): Observable<any> {
    return this.http.get(this.endpoint + 'getAllProductWithImage');
  }
 public  getProductsbyName(name:String): Observable<any> {
    var data={name:name};
    return this.http.post(this.endpoint + 'getProductByName',data,{responseType: 'json'});
  }
  public  getProductsbyCategory(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'getByCategory',data,{responseType: 'json'});
  }
  public updateProduct(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'updateProduct',data,{responseType: 'text'});
  }

  public sortBySize(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'sortBySize',data,{responseType: 'json'});
  }
  public  sortByPrice(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'sortByPrice',data,{responseType: 'json'});
  }
  public login(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'login',data,{responseType: 'json'});
  }
  public forgotPassword(data:any): Observable<any> {
    return this.http.put(this.endpoint + 'changePassword',data,{responseType: 'text'});
  }
  public register(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addCustomer',data,{responseType: 'text'});
  }
  public addToCart(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addToCart',data,{responseType: 'json'});
  }
  public addToCartMultiple(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addToCartMultiple',data,{responseType: 'json'});
  }
  public getCartById(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'getCartById',data,{responseType: 'json'});
  }
  public updateCart(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'updateCart',data,{responseType: 'json'});
  }
  public deleteCart(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'deleteCart',data,{responseType: 'text'});
  }
  public addSell(data:any): Observable<any> {
    return this.http.post(this.endpoint + 'addSell',data,{responseType: 'text'});
  }
  public sendfeedback(feedback:any): Observable<any> {
    return this.http.post(this.endpoint+`sendfeedback`, feedback,{responseType: 'text'});
  }

  public getfeedback(feedback:any): Observable<any> {
    return this.http.post(this.endpoint+`getfeedback`, feedback,{responseType: 'text'});
  }

  public sendOrderEmail(feedback:any): Observable<any> {
    return this.http.post(this.endpoint+ `sendOrderEmail`, feedback,{responseType: 'text'});
  }

  public contactUs(feedback:any): Observable<any> {
    return this.http.post(this.endpoint+`contactUs`, feedback,{responseType: 'text'});
  }

  public sendRegisterEmail(customer: any): Observable<any> {
    return this.http.post<any>(this.endpoint+`sendRegisterEmail`, customer);
  }

  public allLocation():Observable<any> {

    return this.http.get(this.endpoint+`findAllLocations`,{responseType: 'json'});
  }

}
