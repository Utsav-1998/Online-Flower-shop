import { Component, OnInit, OnChanges, AfterContentInit, AfterContentChecked, AfterViewChecked, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { SharedServiceService } from './shared-service.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit,AfterViewChecked{

  constructor( private ss: SharedServiceService,private cd:ChangeDetectorRef) { }

  ngOnInit(): void {
    
  }
  
  ngAfterViewChecked(){
    this.loggedInFlag=this.ss.isLoggedin;
    this.fname=this.ss.userName;
    this.cartLength=this.ss.cartItem.length;
    this.cd.detectChanges();
  }
  cartLength:number=0;
  loggedInFlag!:boolean;
  fname :string='';

public  openNav(): void {
    document.getElementById("mySidenav").style.width = "200px";
  }
  
 public closeNav(): void {
    document.getElementById("mySidenav").style.width = "0";
  }

 public logout(){
    this.ss.isLoggedin = false;
    this.ss.userName = '';
    this.ss.userDetails = {};
    this.ss.cartItem=[];
    alert("Do you Really Want to Logout??")
    document.getElementById("mySidenav").style.width = "0";
  }


}
