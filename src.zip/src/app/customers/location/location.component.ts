import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {

  constructor(private cs:CustomerServiceService) { }
  
  public pList: any = [];
  public tempList: any = [];
  pageNumber = 1;
  pageSize = 3;

  ngOnInit(): void {
    this.getLocation();
  }
  
 public  getLocation():void{
    this.cs.allLocation().subscribe((res)=>{
      console.log(res);
      this.pList = res;
      this.tempList = this.pList.slice(this.pageSize * (this.pageNumber - 1), (this.pageSize * (this.pageNumber - 1)) + this.pageSize)
    });
    
  }
}
