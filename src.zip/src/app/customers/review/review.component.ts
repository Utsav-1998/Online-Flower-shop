import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerServiceService } from '../customer-service.service';
import { SharedServiceService } from '../shared-service.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {

  constructor(private ss:SharedServiceService,private cs:CustomerServiceService,
    private router:Router) { }
  
  name:string='';
	email: string ='';
	subject: string='';
	ratings:string='';
  des :string='';
  namePattern = "^[aA-zZ_-][^0-9]{2,15}$";
  emailPattern = "[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}";
  desPattern = "^[aA-zZ_ -][^0-9]{2,30}$";
  subPattern = "^[aA-zZ_ -][^0-9]{2,30}$";

  ngOnInit(): void {
  }
  
 public feedback(): void{
    var feedback = {
      name: this.name,
      email: this.email,
      subject:this.subject,
      ratings:this.ratings,
      des:this.des
    };
    
    this.cs.getfeedback(feedback).subscribe(
      feedback => {
        console.log(feedback);
      }
    )

    this.cs.sendfeedback(feedback).subscribe(
      feedback => {
        this.feedback = feedback;
        console.log(feedback);
      }
    )

    this.cs.sendOrderEmail(feedback).subscribe(
      feedback => {
        this.feedback = feedback;
        console.log(feedback);
      }
    ) 

    alert(`Your Feedback has been submitted successfully. \n Please check your email for the Order confirmation`);

    this.router.navigate(['customers/products']);
  }

}
