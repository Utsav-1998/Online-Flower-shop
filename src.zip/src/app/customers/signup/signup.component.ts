import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  

  constructor(private cs: CustomerServiceService,
    private router: Router ) { }

  ngOnInit(): void {
  }
  
  fn :string='';
  ln :string='';
  em :string='';
  pass:string='';
  mo:string='';
  ci:string='';
  co:string='';
  errMsg:string='';
  title:string ='';
  fnamePattern = "^[aA-zZ_-][^0-9]{2,15}$";
  lnamePattern = "^[aA-zZ_-][^0-9]{2,15}$";
  pwdPattern = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}";
  mobnumPattern = "^((\\+91-?)|0)?[0-9]{10}$"; 
  emailPattern = "[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}";
  Country = "^[aA-zZ_-][^0-9]{2,15}$";
  cityPattern  = "^[aA-zZ_-][^0-9]{2,15}$";


 public  register(): void{
    var data={
      title:this.title,
      fname: this.fn,
      lname: this.ln,
      email : this.em,
      password : this.pass,
      mobile : this.mo,
      city : this.ci,
      country : this.co
    };
    this.cs.register(data).subscribe((data1:any) =>{
      console.log(data1);
      if(data1=="Success"){
        this.router.navigate(['customers/login']);        
      }else{
        this.errMsg=data1;
      }
    });
    this.cs.sendRegisterEmail(data).subscribe((res:any)=>{
      console.log(res);
    });
  }

}
