export interface user {
    fn: string;
    ln: string;
    em: string;
    pass: string;
    mo: string;
    ci: string;
    co: string;
    errMsg: string;
    title: string[];
}